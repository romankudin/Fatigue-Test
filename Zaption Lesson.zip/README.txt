A standalone lesson is a web bundle that allows you to play back Zaption lessons even after our service shuts down on September 30th.

To get things working, you need to put this entire folder onto a web host. Then everybody who accesses it via HTTP or HTTPS will see the Zaption lesson with full interactivity, even after Zaption shuts down.

Note that just opening the HTML file in your browser (with the file:// protocol) will NOT work. These files must be accessed through a web server via HTTP or HTTPS.

Generally, the data from these standalone lessons will not be stored anywhere. Advanced users can set a "webhook URL" when downloading the lesson, which will allow data to be transmitted via HTTP POSTs to a receiving server of their choosing. This will require programming a script to process this data.